VO LAM OFFLINE - ANDROID PROTOTYPE 0.1

This is an early playable offline prototype wrapped in a native Android WebView.
Features: landscape mode, touch joystick, basic attack, skill, potion, wolves, XP/leveling, gold, quest counter, local save.

BUILD APK ON GITHUB (NO ANDROID STUDIO NEEDED):
1. Extract the VoLamOffline_Android_Project.zip file on your phone or computer.
2. Sign in to GitHub and create a new repository named VoLamOffline. A free private repository is fine.
3. Upload the CONTENTS of the VoLamOffline folder to the repository root. Important: upload the .github folder too; it contains the automatic APK build workflow.
4. Open the repository's Actions tab. If GitHub asks to enable Actions, enable it.
5. Select "Build Vo Lam Offline APK" then press "Run workflow" (or wait for the first push build to finish).
6. Open the completed run. Under Artifacts, download "VoLamOffline-debug-apk".
7. Extract the downloaded artifact ZIP to get app-debug.apk, then open the APK on your Android phone to install it. Android may ask you to allow installation from that browser/file manager; only allow it for the file you just built from your own repository.

The workflow uses Java 17, Gradle 8.7 and Android SDK 35, and builds app/build/outputs/apk/debug/app-debug.apk.
No signing key or GitHub secret is needed for this debug test APK. It is for testing, not Play Store release.

LOCAL BUILD:
Open this folder (VoLamOffline) in Android Studio, sync Gradle, then run Build > Build Bundle(s) / APK(s) > Build APK(s).

No network permission is requested. Save data stays in the app's local WebView storage.
This is a prototype, not a finished commercial MMORPG. Art is drawn procedurally in the game canvas.
